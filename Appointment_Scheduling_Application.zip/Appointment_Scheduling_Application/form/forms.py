from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, DateField, EmailField, TextAreaField, FileField , TimeField , SubmitField
from wtforms.validators import DataRequired, Email, Optional, Length, ValidationError
from models.user import Patient, Doctor

class LoginForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    role = SelectField('Role', choices=[('patient', 'Patient'), ('doctor', 'Doctor')], validators=[DataRequired()])

class PatientRegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=25)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=50)])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    phone_number = StringField('Phone Number', validators=[DataRequired(), Length(min=10, max=15)])

    def validate_username(self, username):
        if Patient.query.filter_by(username=username.data).first() or Doctor.query.filter_by(username=username.data).first():
            raise ValidationError('Username already exists. Please choose a different username.')

    def validate_email(self, email):
        if Patient.query.filter_by(email=email.data).first() or Doctor.query.filter_by(email=email.data).first():
            raise ValidationError('Email already exists. Please choose a different email.')

class DoctorRegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=25)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=50)])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    phone_number = StringField('Phone Number', validators=[DataRequired(), Length(min=10, max=15)])
    specialty = StringField('Specialty', validators=[DataRequired(), Length(min=2, max=50)])

    def validate_username(self, username):
        if Patient.query.filter_by(username=username.data).first() or Doctor.query.filter_by(username=username.data).first():
            raise ValidationError('Username already exists. Please choose a different username.')

    def validate_email(self, email):
        if Patient.query.filter_by(email=email.data).first() or Doctor.query.filter_by(email=email.data).first():
            raise ValidationError('Email already exists. Please choose a different email.')

class AppointmentForm(FlaskForm):
    doctor_id = SelectField('Doctor', validators=[DataRequired()])
    appointment_date = DateField('Date', format='%Y-%m-%d', validators=[DataRequired()])
    appointment_time = TimeField('Time', format='%H:%M', validators=[DataRequired()])
    submit = SubmitField('Book Appointment')


class NotesForm(FlaskForm):
    notes = TextAreaField('Notes', validators=[DataRequired()])
    prescription = TextAreaField('Prescription')
    submit = SubmitField('Save')

class ReferralForm(FlaskForm):
    referred_doctor_id = SelectField('Referred Doctor', coerce=int, validators=[DataRequired()])
    reason = TextAreaField('Reason for Referral', validators=[DataRequired()])
    notes = TextAreaField('Notes to Share')
    submit = SubmitField('Refer')