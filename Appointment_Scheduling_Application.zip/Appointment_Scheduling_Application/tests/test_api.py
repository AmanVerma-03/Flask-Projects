def test_home(client):
    response = client.get("/")
    assert b"<title>Hospital Management Portal</title>" in response.data

def test_login(client):
    response = client.get("/login")
    assert b"<title>Login</title>" in response.data

def test_login_post_patient(client):
    response = client.post("/login", data={"email": "amanverma03082000@gmail.com", "password": "Aman@123", "role":"patient"})
    assert response.status_code == 302
    assert b'<a href="/patient/dashboard">/patient/dashboard</a>' in response.data