import pytest 
from app import create_app,create_tables


@pytest.fixture()
def app():
    app = create_app()
    app.config['WTF_CSRF_ENABLED'] = False
    create_tables(app)

    yield app


@pytest.fixture()
def client(app):
    return app.test_client()
    