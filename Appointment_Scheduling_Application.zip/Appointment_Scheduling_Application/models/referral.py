from extensions import db
from datetime import datetime

class Referral(db.Model):
    __tablename__ = 'referrals'
    referral_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    referring_doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    referred_doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    date_referred = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)