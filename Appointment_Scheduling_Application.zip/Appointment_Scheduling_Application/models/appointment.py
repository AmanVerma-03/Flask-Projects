from datetime import datetime, time
from extensions import db

class Appointment(db.Model):
    __tablename__ = 'appointments'

    appointment_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    appointment_time = db.Column(db.Time, nullable=False)
    status = db.Column(db.String(50), nullable=False, default='Scheduled')
    notes = db.Column(db.Text)

    SCHEDULED = 'Scheduled'
    ATTENDED = 'Attended'
    CANCELED = 'Canceled'

    def is_within_working_hours(self):
        start_time = time(9, 0)
        end_time = time(21, 0)
        return start_time <= self.appointment_time <= end_time

    @classmethod
    def is_slot_available(cls, doctor_id, appointment_date, appointment_time):
        existing_appointment = cls.query.filter_by(
            doctor_id=doctor_id,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            status=cls.SCHEDULED
        ).first()
        return existing_appointment is None
