from extensions import db

class Prescription(db.Model):
    __tablename__ = 'prescriptions'
    prescription_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.appointment_id'), nullable=False)
    prescription_text = db.Column(db.Text, nullable=False)
    date_prescribed = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp())

    # Add these relationships
    patient = db.relationship('Patient', backref='prescriptions')
    doctor = db.relationship('Doctor', backref='prescriptions')
    appointment = db.relationship('Appointment', backref='prescriptions')