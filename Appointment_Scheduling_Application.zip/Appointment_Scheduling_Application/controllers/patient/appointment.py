from flask import Blueprint, render_template, session, redirect, url_for, request, flash, abort
from datetime import datetime, timedelta
from models.user import Patient, Doctor
from models.appointment import Appointment
from extensions import db
from form.forms import AppointmentForm

patient_appointment_bp = Blueprint('patient_appointment', __name__)

@patient_appointment_bp.route('/book_appointment', methods=['GET', 'POST'])
def book_appointment():
    if session.get('user_type') != 'patient':
        return redirect(url_for('auth.login'))
    
    doctors = Doctor.query.all()
    form = AppointmentForm()
    
    form.doctor_id.choices = [(doctor.doctor_id, f"{doctor.full_name} ({doctor.specialty})") for doctor in doctors]
    
    if form.validate_on_submit():
        doctor_id = form.doctor_id.data
        appointment_date = form.appointment_date.data
        appointment_time = form.appointment_time.data
        
        # Check if the time slot is within working hours
        if not Appointment(appointment_time=appointment_time).is_within_working_hours():
            flash('Appointments can only be booked between 9 AM and 9 PM.', 'danger')
            return render_template('patient/book_appointment.html', form=form, doctors=doctors)
        
        # Check if the slot is available
        if not Appointment.is_slot_available(doctor_id, appointment_date, appointment_time):
            flash('This time slot is already booked. Please choose another time.', 'danger')
            return render_template('patient/book_appointment.html', form=form, doctors=doctors)
        
        # Create and save the appointment
        appointment = Appointment(
            patient_id=session['user_id'],
            doctor_id=doctor_id,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            status=Appointment.SCHEDULED
        )
        db.session.add(appointment)
        db.session.commit()
        flash('Appointment booked successfully!', 'success')
        return redirect(url_for('patient.dashboard'))
    
    return render_template('patient/book_appointment.html', form=form, doctors=doctors)

@patient_appointment_bp.route('/reschedule_appointment/<int:appointment_id>', methods=['GET', 'POST'])
def reschedule_appointment(appointment_id):
    if session.get('user_type') != 'patient':
        return redirect(url_for('auth.login'))

    appointment = Appointment.query.get_or_404(appointment_id)
    if appointment.patient_id != session['user_id']:
        abort(403)  # Forbidden

    if appointment.status == Appointment.ATTENDED or appointment.status == Appointment.CANCELED:
        flash('Cannot reschedule an attended or canceled appointment.', 'danger')
        return redirect(url_for('patient.dashboard'))

    form = AppointmentForm(obj=appointment)

    # Populate doctor choices
    doctors = Doctor.query.all()
    form.doctor_id.choices = [(doctor.doctor_id, f"{doctor.full_name} ({doctor.specialty})") for doctor in doctors]

    if request.method == 'POST' and form.validate_on_submit():
        doctor_id = form.doctor_id.data
        appointment_date = form.appointment_date.data
        appointment_time = form.appointment_time.data

        # Check if the time slot is within working hours and available
        if not Appointment(appointment_time=appointment_time).is_within_working_hours():
            flash('Appointments can only be booked between 9 AM and 9 PM.', 'danger')
            return render_template('patient/reschedule_appointment.html', form=form, appointment=appointment)
        
        if not Appointment.is_slot_available(doctor_id, appointment_date, appointment_time):
            flash('This time slot is already booked. Please choose another time.', 'danger')
            return render_template('patient/reschedule_appointment.html', form=form, appointment=appointment)
        
        # Update and save the appointment
        appointment.doctor_id = doctor_id
        appointment.appointment_date = appointment_date
        appointment.appointment_time = appointment_time

        db.session.commit()
        flash('Appointment rescheduled successfully!', 'success')
        return redirect(url_for('patient.dashboard'))

    return render_template('patient/reschedule_appointment.html', form=form, appointment=appointment)


@patient_appointment_bp.route('/cancel_appointment/<int:appointment_id>', methods=['POST'])
def cancel_appointment(appointment_id):
    if session.get('user_type') != 'patient':
        return redirect(url_for('auth.login'))

    appointment = Appointment.query.get_or_404(appointment_id)
    
    if appointment.patient_id != session['user_id']:
        abort(403)  # Forbidden

    if appointment.status == Appointment.ATTENDED:
        flash('Cannot cancel an attended appointment.', 'danger')
        return redirect(url_for('patient.dashboard'))

    appointment.status = Appointment.CANCELED
    db.session.commit()
    
    flash('Appointment canceled successfully.', 'success')
    return redirect(url_for('patient.dashboard'))
