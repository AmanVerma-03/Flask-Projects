from flask import Blueprint, render_template, session, redirect, url_for
from models.user import Patient
from models.appointment import Appointment
from models.prescription import Prescription

patient_bp = Blueprint('patient', __name__)

@patient_bp.route('/dashboard')
def dashboard():
    if session.get('user_type') != 'patient':
        return redirect(url_for('auth.login'))
    patient = Patient.query.get(session['user_id'])
    appointments = Appointment.query.filter_by(patient_id=patient.patient_id).all()
    return render_template('patient/dashboard.html', patient=patient, appointments=appointments)

@patient_bp.route('/view_prescriptions')
def view_prescriptions():
    if session.get('user_type') != 'patient':
        return redirect(url_for('auth.login'))
    patient = Patient.query.get(session['user_id'])
    prescriptions = Prescription.query.filter_by(patient_id=patient.patient_id).order_by(Prescription.prescription_id.desc()).all()
    return render_template('patient/view_prescriptions.html', patient=patient, prescriptions=prescriptions)


