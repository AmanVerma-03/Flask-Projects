from flask import Blueprint, render_template, session, redirect, url_for, request
from models.user import Patient, Doctor
from models.appointment import Appointment
from models.user import db

patient_search_bp = Blueprint('patient_search', __name__)

@patient_search_bp.route('/search_doctors', methods=['GET', 'POST'])
def search_doctors():
    if session.get('user_type') != 'patient':
        return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        specialty = request.form['specialty']
        available_date = request.form['available_date']
        available_time = request.form['available_time']
        
        doctors = Doctor.query.filter_by(specialty=specialty).all()
        available_doctors = []
        for doctor in doctors:
            appointments = Appointment.query.filter_by(doctor_id=doctor.doctor_id, appointment_date=available_date, appointment_time=available_time).all()
            if not appointments:
                available_doctors.append(doctor)
        
        return render_template('patient/search_results.html', doctors=available_doctors)
    
    return render_template('patient/search_doctors.html')
