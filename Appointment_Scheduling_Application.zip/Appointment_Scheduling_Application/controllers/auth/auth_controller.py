from flask import Blueprint, render_template, redirect, url_for, request, flash, session
from werkzeug.security import check_password_hash
from models.user import db, Patient, Doctor
from form.forms import LoginForm, PatientRegistrationForm, DoctorRegistrationForm

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data
        role = form.role.data
        
        if role == 'patient':
            user = Patient.query.filter_by(email=email).first()
        elif role == 'doctor':
            user = Doctor.query.filter_by(email=email).first()
        
        if user and user.password == password:
            session['user_id'] = user.patient_id if role == 'patient' else user.doctor_id
            session['user_type'] = role

            if role == 'patient':
                return redirect(url_for('patient.dashboard'))
            elif role == 'doctor':
                return redirect(url_for('doctor.dashboard'))
            else:
                flash('Invalid role selected', 'danger')
        else:
            flash('Invalid email or password', 'danger')

    return render_template('auth/login.html', form=form)

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('auth.login'))

@auth_bp.route('/register/patient', methods=['GET', 'POST'])
def register_patient():
    form = PatientRegistrationForm()
    if form.validate_on_submit():
        if not Patient.query.filter_by(username=form.username.data).first() and not Doctor.query.filter_by(username=form.username.data).first():
            if not Patient.query.filter_by(email=form.email.data).first() and not Doctor.query.filter_by(email=form.email.data).first():
                patient = Patient(
                    username=form.username.data,
                    password=form.password.data,
                    full_name=form.full_name.data,
                    email=form.email.data,
                    phone_number=form.phone_number.data
                )
                db.session.add(patient)
                db.session.commit()
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('auth.login'))
            else:
                flash('Email already exists. Please choose a different email.', 'danger')
        else:
            flash('Username already exists. Please choose a different username.', 'danger')
    return render_template('auth/register_patient.html', form=form)

@auth_bp.route('/register/doctor', methods=['GET', 'POST'])
def register_doctor():
    form = DoctorRegistrationForm()
    if form.validate_on_submit():
        if not Patient.query.filter_by(username=form.username.data).first() and not Doctor.query.filter_by(username=form.username.data).first():
            if not Patient.query.filter_by(email=form.email.data).first() and not Doctor.query.filter_by(email=form.email.data).first():
                doctor = Doctor(
                    username=form.username.data,
                    password=form.password.data,
                    full_name=form.full_name.data,
                    email=form.email.data,
                    phone_number=form.phone_number.data,
                    specialty=form.specialty.data
                )
                db.session.add(doctor)
                db.session.commit()
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('auth.login'))
            else:
                flash('Email already exists. Please choose a different email.', 'danger')
        else:
            flash('Username already exists. Please choose a different username.', 'danger')
    return render_template('auth/register_doctor.html', form=form)
