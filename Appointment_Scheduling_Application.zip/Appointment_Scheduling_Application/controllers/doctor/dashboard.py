from flask import Blueprint, render_template, session, redirect, url_for
from models.user import Doctor
from models.appointment import Appointment

doctor_bp = Blueprint('doctor', __name__)

@doctor_bp.route('/dashboard')
def dashboard():
    if session.get('user_type') != 'doctor':
        return redirect(url_for('auth.login'))
    doctor = Doctor.query.get(session['user_id'])
    appointments = Appointment.query.filter_by(doctor_id=doctor.doctor_id).all()
    return render_template('doctor/dashboard.html', doctor=doctor, appointments=appointments)
