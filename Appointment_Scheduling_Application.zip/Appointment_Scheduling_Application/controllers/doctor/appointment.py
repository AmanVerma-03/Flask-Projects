from flask import Blueprint, render_template, session, redirect, url_for, flash , abort , request
from models.appointment import Appointment
from models.user import  db ,Patient
from models.prescription import Prescription

doctor_appointment_bp = Blueprint('doctor_appointment', __name__)

@doctor_appointment_bp.route('/mark_attended/<int:appointment_id>', methods=['POST'])
def mark_attended(appointment_id):
    if session.get('user_type') != 'doctor':
        return redirect(url_for('auth.login'))

    appointment = Appointment.query.get_or_404(appointment_id)
    
    if appointment.doctor_id != session['user_id']:
        abort(403)  # Forbidden

    if appointment.status == Appointment.ATTENDED:
        flash('Appointment is already marked as attended.', 'danger')
    elif appointment.status == Appointment.CANCELED:
        flash('Cannot mark a canceled appointment as attended.', 'danger')
    else:
        appointment.status = Appointment.ATTENDED
        db.session.commit()
        flash('Appointment marked as attended.', 'success')

    # Redirect to doctor's dashboard or appropriate page
    return redirect(url_for('doctor.dashboard'))

@doctor_appointment_bp.route('/cancel_appointment/<int:appointment_id>', methods=['POST'])
def cancel_appointment(appointment_id):
    if session.get('user_type') != 'doctor':
        return redirect(url_for('auth.login'))

    appointment = Appointment.query.get_or_404(appointment_id)
    
    if appointment.doctor_id != session['user_id']:
        abort(403)  # Forbidden

    if appointment.status == Appointment.CANCELED:
        flash('Appointment is already canceled.', 'danger')
    elif appointment.status == Appointment.ATTENDED:
        flash('Cannot cancel an attended appointment.', 'danger')
    else:
        appointment.status = Appointment.CANCELED
        db.session.commit()
        flash('Appointment canceled successfully.', 'success')

    # Redirect to doctor's dashboard or appropriate page
    return redirect(url_for('doctor.dashboard'))

@doctor_appointment_bp.route('/add_notes/<int:appointment_id>', methods=['GET', 'POST'])
def add_notes(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    if request.method == 'POST':
        notes = request.form['notes']
        appointment.notes = notes
        db.session.commit()
        flash('Notes added successfully', 'success')
        return redirect(url_for('doctor.dashboard'))
    return render_template('doctor/add_notes.html', appointment=appointment)

@doctor_appointment_bp.route('/write_prescription/<int:appointment_id>', methods=['GET', 'POST'])
def write_prescription(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    if request.method == 'POST':
        prescription_text = request.form['prescription']
        prescription = Prescription(
            patient_id=appointment.patient_id,
            doctor_id=appointment.doctor_id,
            appointment_id=appointment_id,
            prescription_text=prescription_text
        )
        db.session.add(prescription)
        db.session.commit()
        flash('Prescription added successfully', 'success')
        return redirect(url_for('doctor.dashboard'))
    return render_template('doctor/write_prescription.html', appointment=appointment)