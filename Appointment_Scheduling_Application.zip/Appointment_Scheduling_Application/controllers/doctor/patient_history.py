from flask import Blueprint, render_template, session, redirect, url_for , request , flash
from models.user import Doctor, Patient , db
from models.appointment import Appointment
from models.prescription import Prescription
from models.referral import Referral

doctor_patient_history_bp = Blueprint('doctor_patient_history', __name__)



@doctor_patient_history_bp.route('/patient_history/<int:patient_id>')
def patient_history(patient_id):
    if session.get('user_type') != 'doctor':
        return redirect(url_for('auth.login'))

    patient = Patient.query.get_or_404(patient_id)
    appointments = Appointment.query.filter_by(patient_id=patient_id).order_by(Appointment.appointment_date.desc()).all()
    prescriptions = Prescription.query.filter_by(patient_id=patient_id).order_by(Prescription.prescription_id.desc()).all()

    return render_template('doctor/patient_history.html', patient=patient, appointments=appointments, prescriptions=prescriptions)

@doctor_patient_history_bp.route('/write_prescription/<int:appointment_id>', methods=['GET', 'POST'])
def write_prescription(appointment_id):
    if session.get('user_type') != 'doctor':
        return redirect(url_for('auth.login'))
    
    appointment = Appointment.query.get(appointment_id)
    
    if request.method == 'POST':
        prescription_text = request.form['prescription']
        
        prescription = Prescription(
            patient_id=appointment.patient_id,
            doctor_id=session['user_id'],
            appointment_id=appointment_id,
            prescription_text=prescription_text
        )
        db.session.add(prescription)
        db.session.commit()
        flash('Prescription added successfully.', 'success')
        return redirect(url_for('doctor.dashboard'))
    
    return render_template('doctor/write_prescription.html', appointment=appointment)


@doctor_patient_history_bp.route('/refer_patient/<int:patient_id>', methods=['GET', 'POST'])
def refer_patient(patient_id):
    if session.get('user_type') != 'doctor':
        return redirect(url_for('auth.login'))

    patient = Patient.query.get_or_404(patient_id)
    doctors = Doctor.query.filter(Doctor.doctor_id != session['user_id']).all()

    if request.method == 'POST':
        referred_doctor_id = request.form['referred_doctor_id']
        reason = request.form['reason']

        referral = Referral(
            patient_id=patient_id,
            referring_doctor_id=session['user_id'],
            referred_doctor_id=referred_doctor_id,
            reason=reason
        )
        db.session.add(referral)
        db.session.commit()
        flash('Patient referred successfully.', 'success')
        return redirect(url_for('doctor_patient_history.patient_history', patient_id=patient_id))

    return render_template('doctor/refer_patient.html', patient=patient, doctors=doctors)
