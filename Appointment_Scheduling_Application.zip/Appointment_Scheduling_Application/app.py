from flask import Flask, render_template
from models.user import db
from controllers.auth.auth_controller import auth_bp
from controllers.patient.dashboard import patient_bp
from controllers.patient.appointment import patient_appointment_bp
from controllers.doctor.dashboard import doctor_bp
from controllers.doctor.appointment import doctor_appointment_bp
from controllers.doctor.patient_history import doctor_patient_history_bp
from models import user, appointment , prescription , referral# Import both user and appointment models

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///healthy1.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SECRET_KEY'] = 'AmanVerma'
    app.config['WTF_CSRF_ENABLED'] = False

    db.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(patient_bp, url_prefix='/patient')
    app.register_blueprint(patient_appointment_bp, url_prefix='/patient')
    app.register_blueprint(doctor_bp, url_prefix='/doctor')
    app.register_blueprint(doctor_appointment_bp, url_prefix='/doctor')

    app.register_blueprint(doctor_patient_history_bp, url_prefix='/doctor')
    
    @app.route("/")
    def index():
        return render_template('index.html')

    # Error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('error.html', error_code=404, error_message="Page not found"), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('error.html', error_code=500, error_message="Internal server error"), 500

    @app.errorhandler(403)
    def forbidden(e):
        return render_template('error.html', error_code=403, error_message="Forbidden"), 403

    @app.errorhandler(401)
    def unauthorized(e):
        return render_template('error.html', error_code=401, error_message="Unauthorized"), 401

    @app.errorhandler(400)
    def bad_request(e):
        return render_template('error.html', error_code=400, error_message="Bad Request"), 400

    @app.errorhandler(Exception)
    def handle_exception(e):
        # Handle generic exceptions
        return render_template('error.html', error_code=500, error_message=str(e)), 500
    
    return app

def create_tables(app):
    with app.app_context():
        db.create_all()

if __name__ == '__main__':
    app = create_app()
    create_tables(app)
    app.run(debug=True)
