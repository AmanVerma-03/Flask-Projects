from flask import Blueprint, request,abort, jsonify,redirect,render_template, url_for, session
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity, get_jwt
from werkzeug.security import generate_password_hash, check_password_hash
from models.model import db, Employee, EmployeeRole, TokenBlacklist, Manager 
from routes.Employee.Forms import RegistrationForm, LoginForm
import datetime

auth = Blueprint('auth', __name__)


@auth.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST':
        email = form.email.data
        password = form.password.data
        role = form.role.data

        print(form.email.data, form.role)


        # Check if the user exists and the password is correct based on role
        if role == 'employee':
            user = Employee.query.filter_by(email=email).first()
        elif role == 'manager':
            user = Manager.query.filter_by(email=email).first()
        else:
            #return redirect(url_for('auth.login'))
            return "Invalid Role"

        if user and check_password_hash(user.password, password):
            # Create JWT token
            session['user_id'] = user.serialize()
            if role == 'employee':
                return redirect(url_for('employee.dash'))
            else:
                session['manager'] = True
                return redirect(url_for('manager_profile.manager_dashboard'))
            return "Logged In",200
        else:
           # return redirect(url_for('auth.login'))
            abort(401)

    return render_template('login.html', form=form)





@auth.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


@auth.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    print(form.validate_on_submit(), form.errors)
    if form.validate_on_submit():
        # Handle form data
        name = form.name.data
        email = form.email.data
        password = form.password.data
        address = form.address.data
        pan_number = form.pan_number.data

        # Register the user and save data to the database or perform other operations
        existing_user = Employee.query.filter_by(email=email).first()
        if existing_user:
            #return jsonify({'error': 'Email already registered'}), 400
            abort(400)
        # Create a new employee
        employee_role = EmployeeRole.query.filter_by(role_name='Employee').first()
        hashed_password = generate_password_hash(password)
        new_employee = Employee(name=name, email=email, password=hashed_password,
                                address=address, pan_number=pan_number,
                                role=employee_role, created_on=datetime.datetime.utcnow())
        db.session.add(new_employee)
        db.session.commit()
       
        return redirect(url_for('auth.login'))  # Replace 'login' with the appropriate route

    return render_template('employee/employee_register.html', form=form)
