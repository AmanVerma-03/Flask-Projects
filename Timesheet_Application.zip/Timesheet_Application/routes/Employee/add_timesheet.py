from flask import Blueprint, abort, request, render_template, redirect, url_for, flash, session
from models.model import db, Timesheet, Employee
from datetime import datetime
from enum import Enum
from .Forms import EmployeeProfileForm, TimesheetForm
from .login_decorator import login_session_required

employee = Blueprint('employee', __name__)

class TimesheetStatus(Enum):
    IN_PROCESS = 'in_process'
    APPROVED = 'approved'
    REJECTED = 'rejected'

@employee.route('/dashboard')
@login_session_required
def dash():
    employee = session['user_id']
    return render_template('employee/employee_dashboard.html', employee=employee)

@employee.route('/add_timesheet', methods=['GET', 'POST'])
@login_session_required
def add_timesheet():
    form = TimesheetForm()
    if form.validate_on_submit():
        date = form.date.data
        hours_spent = form.hours_spent.data
        description = form.description.data
        type = form.type.data
        attachment = form.attachment.data

        if hours_spent > 8:
            abort(400)

        status = TimesheetStatus.IN_PROCESS.value
        employee_id = session['user_id'].get('employee_id')

        timesheet = Timesheet(
            date=date,
            hours_spent=hours_spent,
            description=description,
            status=status,
            type=type,
            employee_id=employee_id,
            filled_on=datetime.utcnow()
        )

        if attachment:
            timesheet.attachment = attachment.read()

        db.session.add(timesheet)
        db.session.commit()

        flash('Timesheet added successfully!', 'success')
        return redirect(url_for('employee.view_timesheets'))

    return render_template('employee/add_timesheet.html', form=form)

@employee.route('/employee_profile', methods=['GET', 'POST'])
@login_session_required
def employee_profile():
    form = EmployeeProfileForm()
    employee = session['user_id']
    if form.validate_on_submit():
        name = form.name.data
        email = form.email.data
        address = form.address.data

        employee = Employee.query.get(employee['employee_id'])
        if employee:
            employee.name = name
            employee.address = address
            db.session.commit()
            session.pop('user_id', None)
            session['user_id'] = employee.serialize()
        else:
            abort(404)

        return redirect(url_for('employee.dash'))

    form.name.data = employee['name']
    form.email.data = employee['email']
    form.address.data = employee['address']

    return render_template('employee/employee_profile.html', form=form, employee=employee)

@employee.route('/view_timesheets')
@login_session_required
def view_timesheets():
    employee_id = session['user_id'].get('employee_id')
    employee = Employee.query.get_or_404(employee_id)
    timesheets = Timesheet.query.filter_by(employee_id=employee_id).all()
    return render_template('employee/view_timesheets.html', timesheets=timesheets)
