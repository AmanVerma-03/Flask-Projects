from functools import wraps
from flask import session, redirect, url_for

def login_session_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            # User is not logged in, redirect to the login page
            return redirect(url_for('auth.login'))
        
        # User is logged in, proceed with the requested function
        return func(*args, **kwargs)
    
    return wrapper


def manager_session_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'manager' not in session or 'user_id' not in session:
            # User is not logged in, redirect to the login page
            return redirect(url_for('auth.login'))
        
        # User is logged in, proceed with the requested function
        return func(*args, **kwargs)
    
    return wrapper