from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, DateField, EmailField, IntegerField,TextAreaField,FileField
from wtforms.validators import DataRequired, Email,Optional, Length

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    role = SelectField('Role', choices=[('employee', 'Employee'), ('manager', 'Manager')])


class TimesheetForm(FlaskForm):
    date = DateField('Date', validators=[DataRequired()])
    hours_spent = IntegerField('Hours Spent', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    type = SelectField('Type', choices=[('Work', 'Work'), ('Leave', 'Leave')], validators=[DataRequired()])
    attachment = FileField('Attachment')

class EmployeeProfileForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    address = StringField('Address', validators=[DataRequired()])

class RegistrationForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    pan_number = StringField('PAN Number', validators=[DataRequired(), Length(9)])

class ManageEmployeeForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    address = StringField('Address', validators=[DataRequired()])

class FilterTimesheetsForm(FlaskForm):
    employee_name = StringField('Employee Name', validators=[Optional()])
    employee_id = IntegerField('Employee ID', validators=[Optional()])
    date = DateField('Date', format='%Y-%m-%d', validators=[Optional()])
    