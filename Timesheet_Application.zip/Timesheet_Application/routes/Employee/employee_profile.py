# employee_profile.py
from flask import Blueprint,abort, request, jsonify, redirect, url_for, render_template
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.model import db, Employee , Timesheet
from .Forms import TimesheetForm
from .login_decorator import login_session_required

employee_profile = Blueprint('employee_profile', __name__)

@employee_profile.route('/edit_timesheets/<int:timesheet_id>' ,methods=['POST','GET'])
@login_session_required
def edit_timesheet(timesheet_id):
    timesheet = Timesheet.query.get_or_404(timesheet_id)
    form = TimesheetForm(obj=timesheet)
    print(form.errors,form.validate_on_submit())
    if form.validate_on_submit():
        form.populate_obj(timesheet)
        db.session.commit()
        return redirect(url_for('employee.view_timesheets', employee_id=timesheet.employee_id))
    return render_template('employee/edit_timesheet.html', form=form, timesheet=timesheet)


@employee_profile.route('/del_timesheets/<int:timesheet_id>')
@login_session_required
def delete_timesheet(timesheet_id):
    timesheet = Timesheet.query.get(timesheet_id)
    if timesheet.status in ['Approved', 'Rejected']:
        #return jsonify({'error': 'Cannot delete timesheet once it is approved or rejected.'}), 400
        abort(400)
    else:
        db.session.delete(timesheet)
        db.session.commit()
        return redirect(url_for('employee.view_timesheets'))
