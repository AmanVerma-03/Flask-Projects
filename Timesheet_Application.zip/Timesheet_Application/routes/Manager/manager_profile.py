# routes/manager/manager_profile.py
from flask import Blueprint, request, jsonify, render_template,redirect,url_for
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.model import db, Employee, Timesheet , Manager
from routes.Employee.Forms import FilterTimesheetsForm
from routes.Employee.login_decorator import manager_session_required

manager_profile = Blueprint('manager_profile', __name__)




@manager_profile.route('/manage_timesheet/<int:timesheet_id>', methods=['GET', 'POST'])
@manager_session_required
def manage_timesheet(timesheet_id):
    timesheet = Timesheet.query.get_or_404(timesheet_id)
    
    if request.method == 'POST':
        status = request.form['status']
        comments = request.form['comments']
        
        timesheet.status = status
        timesheet.comments = comments
        db.session.commit()
        
       # flash('Timesheet status updated successfully!', 'success')
        return redirect(url_for('manager_profile.view_timesheets_filter', employee_id=timesheet.employee_id))
    
    return render_template('manager/manage_timesheet.html', timesheet=timesheet)



@manager_profile.route('/view_timesheets', methods=['GET', 'POST'])
@manager_session_required
def view_timesheets_filter():
    form = FilterTimesheetsForm()
    query = Timesheet.query

    print(form.validate_on_submit())
    if form.validate_on_submit():
        if form.employee_name.data:
            query = query.join(Employee).filter(Employee.name.ilike(f"%{form.employee_name.data}%"))
        if form.employee_id.data:
            query = query.filter(Timesheet.employee_id == form.employee_id.data)
        if form.date.data:
            query = query.filter(Timesheet.date == form.date.data)
    
    timesheets = query.all()

    return render_template('manager/manager_view_timesheets.html', form=form, timesheets=timesheets)



@manager_profile.route('/dashboard')
@manager_session_required
def manager_dashboard():
    return render_template('manager/manager_dashboard.html')


@manager_profile.route('/all_employees')
@manager_session_required
def all_employees():
    employees = Employee.query.all()
    return render_template('manager/manage_all_employees.html',employees=employees)