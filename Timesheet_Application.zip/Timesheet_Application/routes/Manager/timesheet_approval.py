from flask import Blueprint,abort, request, jsonify, render_template, redirect, url_for
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.model import db
from models.model import Timesheet , Employee , Manager
from datetime import datetime
from enum import Enum

from routes.Employee.Forms import ManageEmployeeForm
from routes.Employee.login_decorator import manager_session_required

manager = Blueprint('manager', __name__)

class TimesheetStatus(Enum):
    IN_PROCESS = 'in_process'
    APPROVED = 'approved'
    REJECTED = 'rejected'


@manager.route('/delete_timesheet/<int:timesheet_id>')
@manager_session_required
def delete_timesheet(timesheet_id):
    # Assuming manager has permission to delete any timesheet
    timesheet = Timesheet.query.get(timesheet_id)
    if timesheet:
        db.session.delete(timesheet)
        db.session.commit()
        return redirect(url_for('manager_profile.view_timesheets_filter'))
    else:
        #return jsonify({'error': 'Timesheet not found.'}), 404
        abort(404)

  
@manager.route('/manage_employee/<int:employee_id>', methods=['GET', 'POST'])
@manager_session_required
def manage_employee(employee_id):
    employee = Employee.query.get(employee_id)  # Retrieve employee data from the database

    form = ManageEmployeeForm()
    if form.validate_on_submit():
        # Handle form data
        name = form.name.data
        email = form.email.data
        address = form.address.data


        if employee:
            employee.name = name
            employee.address = address
            db.session.commit()

            return redirect(url_for('manager_profile.all_employees'))
        else:
            #return jsonify({'error': 'Employee not found'}), 404
            abort(404)
    form.name.data = employee.name
    form.email.data = employee.email
    form.address.data = employee.address

    return render_template('manager/manage_employee.html', form=form, employee=employee)
