from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash  # Add this import

db = SQLAlchemy()

class EmployeeRole(db.Model):
    __tablename__ = 'employee_roles'
    id = db.Column(db.Integer, primary_key=True)
    role_name = db.Column(db.String(50), nullable=False, unique=True)

    def __repr__(self):
        return f'<EmployeeRole {self.role_name}>'

class Employee(db.Model, UserMixin):
    __tablename__ = 'employees'
    employee_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)
    created_on = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('employee_roles.id'), nullable=False)
    role = db.relationship('EmployeeRole', backref='employees')
    address = db.Column(db.String(200), nullable=False)
    pan_number = db.Column(db.String(10), nullable=False, unique=True)
    timesheet = db.relationship('Timesheet', backref='employee', uselist=False,lazy=True)

    def __repr__(self):
        return f'<Employee {self.name}>'
    
    def serialize(self):
        return {
            'employee_id': self.employee_id,
            'name': self.name,
            'email': self.email,
            'address': self.address,
            'pan_number': self.pan_number,
            
        }

class Manager(db.Model, UserMixin):
    __tablename__ = 'managers'
    manager_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)
    created_on = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('employee_roles.id'), nullable=False)
    role = db.relationship('EmployeeRole', backref='managers')

    def __repr__(self):
        return f'<Manager {self.name}>'
    
    def serialize(self):
        return {
            'employee_id': self.manager_id,
            'name': self.name,
            'email': self.email,
            
        }

class Timesheet(db.Model):
    __tablename__ = 'timesheets'
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, nullable=False)
    hours_spent = db.Column(db.Integer, nullable=False)
    employee_id = db.Column(db.Integer, db.ForeignKey('employees.employee_id'), nullable=False)
    description = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='In Process')
    filled_on = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    approved_by = db.Column(db.String(100))
    comments = db.Column(db.String(200))
    attachment = db.Column(db.String(200))
    type = db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f'<Timesheet {self.id}>'

class TokenBlacklist(db.Model):
    __tablename__ = 'token_blacklist'
    id = db.Column(db.Integer, primary_key=True)
    jti = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False)

def create_tables(app):
    with app.app_context():
        db.create_all()
        # Add a Manager record
        manager_role = EmployeeRole.query.filter_by(role_name='Manager').first()
        if not manager_role:
            manager_role = EmployeeRole(role_name='Manager')
            db.session.add(manager_role)
            db.session.commit()

        manager = Manager.query.filter_by(email='manager@example.com').first()
        if not manager:
            hashed_password = generate_password_hash('managerpassword')
            new_manager = Manager(name='Manager Name', email='manager@example.com', 
                                  password=hashed_password, role=manager_role,
                                  created_on=datetime.utcnow())
            db.session.add(new_manager)
            db.session.commit()
