from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from models.model import create_tables, db, TokenBlacklist
from routes.auth import auth
from routes.Employee.add_timesheet import employee
from routes.Employee.employee_profile import employee_profile
from routes.Manager.manager_profile import manager_profile  # Corrected import for manager_profile
from routes.Manager.timesheet_approval import manager



app = Flask(__name__)

# Set database URI and secret key here
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///timesheet.db'
app.config['SECRET_KEY'] = 'AMAN VERMA'
app.config['JWT_BLACKLIST_ENABLED'] = True
app.config['JWT_BLACKLIST_TOKEN_CHECKS'] = ['access', 'refresh']

db.init_app(app)
jwt = JWTManager(app)

@jwt.token_in_blocklist_loader
def check_if_token_revoked(jwt_header, jwt_payload):
    jti = jwt_payload['jti']
    token = TokenBlacklist.query.filter_by(jti=jti).first()
    return token is not None

app.register_blueprint(auth, url_prefix="/auth")
app.register_blueprint(employee, url_prefix="/employee")
app.register_blueprint(employee_profile, url_prefix="/employee_profile")
app.register_blueprint(manager_profile, url_prefix="/manager_profile")  # Register manager_profile blueprint
app.register_blueprint(manager,url_prefix="/manager")


@app.route("/")
def index():
    return render_template('index.html')

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error_code=404, error_message="Page not found"), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('error.html', error_code=500, error_message="Internal server error"), 500

@app.errorhandler(403)
def forbidden(e):
    return render_template('error.html', error_code=403, error_message="Forbidden"), 403

@app.errorhandler(401)
def unauthorized(e):
    return render_template('error.html', error_code=401, error_message="Unauthorized"), 401

@app.errorhandler(400)
def bad_request(e):
    return render_template('error.html', error_code=400, error_message="Bad Request"), 400



@app.errorhandler(Exception)
def handle_exception(e):
    # Handle generic exceptions
    return render_template('error.html', error_code=500, error_message=str(e)), 500



if __name__ == '__main__':
    create_tables(app)
    app.run(debug=True)
